#include "header.h"

/*Function to display the database*/
void display_database(Main_node *arr[28])
{
    for(int i = 0; i < 28; i++)  
    {
        if(arr[i] != NULL)
        {
            Main_node *temp_main = arr[i]; 
            while(temp_main)
            {
                printf("[%d]\t%s\t%d\t", i, temp_main->word, temp_main->file_count);
                Sub_node *temp_sub = temp_main->s_link; 
                while(temp_sub)
                {
                    printf("%s\t%d\t", temp_sub->file_name, temp_sub->word_count);
                    temp_sub = temp_sub->sub_link;
                }
                printf("\n");
                temp_main = temp_main->m_link;
            }
        }
    }
}
