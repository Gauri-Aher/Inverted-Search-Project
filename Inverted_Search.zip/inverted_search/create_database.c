#include "header.h"

/*Function to create database*/
int create_database(Main_node *arr[28], Slist **head)
{
    if(*head == NULL)  //checking whether list is empty or not
    {
        return LIST_EMPTY;
    }
    Slist *temp = *head;
    
    /*Printing the file names*/
    while(temp)
    {
        printf("%s->", temp->file);
        temp = temp->link;
    }
    printf("NULL\n");
    
    Slist *temp_list = *head;
    while(temp_list) //traversing till last node of list of file names
    {
        FILE *fptr = fopen(temp_list->file, "r");  //opening file
        if(fptr == NULL)
        {
            printf("Failed to open %s file\n", temp_list->file);
            return FAILURE;
        }

        char word[50];
        while(fscanf(fptr, "%s", word) != EOF)  //getting each word from file till end of the file
        {
            int index = find_index(word);  //finding the index of tne file

            if(arr[index] == NULL)  //checking whether array is empty or not
            {
                /*Creating main node and adding the data and linking it to the array*/
                Main_node *new_main = malloc(sizeof(Main_node));
                if(new_main == NULL)
                {
                    printf("Failed to create new node for main node\n");
                    return FAILURE;
                }

                new_main->file_count = 1;
                strcpy(new_main->word, word);
                new_main->m_link = NULL;

               /*Creating sub node and adding data and linking it to the main node*/
                Sub_node *new_sub = malloc(sizeof(Sub_node));
                if(new_sub == NULL)
                {
                    printf("Failed to create new node for sub node\n");
                    return FAILURE;
                }

                new_sub->word_count = 1;
                strcpy(new_sub->file_name, temp_list->file);
                new_sub->sub_link = NULL;
                new_main->s_link = new_sub;  

                arr[index] = new_main;
            }

            else
            {
                Main_node *temp_main = arr[index];
                int word_present = 0;
                /*checking whether the word is already present or not*/
                while(temp_main)
                {
                    if(strcmp(temp_main->word, word) == 0)
                    {
                        word_present = 1;
                        break;
                    }
                    temp_main = temp_main->m_link;
                }

                if(word_present)  //if word present checking whether it is same file or not
                {
                    Sub_node *temp_sub = temp_main->s_link;
                    int file_present = 0;
                    while(temp_sub)
                    {
                        if(strcmp(temp_sub->file_name, temp_list->file) == 0)
                        {
                            temp_sub->word_count++;
                            file_present = 1;
                            break;
                        }
                        temp_sub = temp_sub->sub_link;
                    }

                    if(!file_present)  //if it is not same file means adding filename with subnode
                    {
                        Sub_node *new_sub = malloc(sizeof(Sub_node));
                        if(new_sub == NULL)
                        {
                            printf("Failed to create new node for sub node\n");
                            return FAILURE;
                        }

                        new_sub->word_count = 1;
                        strcpy(new_sub->file_name, temp_list->file);
                        new_sub->sub_link = temp_main->s_link;
                        temp_main->s_link = new_sub;
                        temp_main->file_count++;  //incrementing the file count
                    }
                }

                else   //if word is not present creating main node and sub node and linking it to the array
                {
                    Main_node *new_main = malloc(sizeof(Main_node));
                    if(new_main == NULL)
                    {
                        printf("Failed to create new node for main node\n");
                        return FAILURE;
                    }

                    new_main->file_count = 1;
                    strcpy(new_main->word, word);
                    new_main->m_link = arr[index];    
                    Sub_node *new_sub = malloc(sizeof(Sub_node));

                    if(new_sub == NULL)
                    {
                        printf("Failed to create new node for sub node\n");
                        return FAILURE;
                    }

                    new_sub->word_count = 1;
                    strcpy(new_sub->file_name, temp_list->file);
                    new_sub->sub_link = NULL;
                    new_main->s_link = new_sub;
                    arr[index] = new_main;
                }
            }
        }
        fclose(fptr);  
        temp_list = temp_list->link;  
    }
    return SUCCESS;
}

/*Function to find the index of the file*/
int find_index(char *word)
{
    char c = word[0];
    if(c >= 'A' && c <= 'Z') /*checking whether the character is uppercase or not*/
    {
        return c - 'A';
    }
    else if (c >= 'a' && c <= 'z') /*checking whether the character is lowercase or not*/
    {
        return c - 'a';
    }
    else if (!isalnum(c) && !isspace(c)) /*checking whether the character is special character or not*/
    {
        return 26;
    }
    else if (c >= '0' && c <= '9')
    {
        return 27;
    }
}

