#include "header.h"

int main(int argc, char *argv[])
{
    Slist *head = NULL;
    Main_node *arr[28] = {NULL};

    read_and_validate(argc, argv, &head); // function call for validating command line arguments
    if(head == NULL)                     // checking whether valid files are passed in the command line arguments
    {
        printf("Usage : ./a.out <.txt file> [.txt file] [.txt file]\n");
        return FAILURE;
    }

    Slist *temp = head;
    printf("\n");
    while(temp)
    {
        printf("%s ", temp->file); // printing the validated file names
        temp = temp->link;
    }

    //printf("NULL\n");

    int choice;
    int create_count = 0;
    int update_count = 0;

    while(1)
    {
        printf("\n1. Create Database\n2. Display Database\n3. Search Database\n4. Save Database\n5. Update Database\n6. Exit\nEnter your option: ");
        scanf("%d", &choice);
        switch (choice)
        {
        case 1:
            if(create_count == 0)
            {
                int result = create_database(arr, &head);  //function call to create database
                if(result == SUCCESS)
                {
                    printf("Database Created Successfully\n");
                    create_count = 1;
                }
                else if(result == LIST_EMPTY)
                {
                    printf("Database created already\n");
                }
            }
            else
            {
                printf("Database created already\n");
            }
            break;

        case 2:
            display_database(arr);  //function call to display database
            break;

        case 3:
            search_database(arr);   //function call to search database
            break;

        case 4:
            if(save_database(arr) == SUCCESS)  //function call to save database
            {
                printf("Database saved in file successfully\n");
            }
            else
            {
                printf("Error in saving file\n");
            }
            break;

        case 5:
            if(create_count == 0 && update_count == 0)   //checking whether the data base is already upadted or created
            {
                if(update_database(arr, &head) == SUCCESS)  //function call to update database
                {
                    printf("Database updated in file successfully\n");
                    update_count = 1;
                }
                else
                {
                    printf("Error in Updating database\n");
                }
            }
            else
            {
                printf("Database already created\n");
            }
            break;

        case 6:
            printf("Exiting...\n");  
            return 0;
            break;

        default:
            printf("Invalid Choice !\n");
        }
    }
}


/*function to validate the command line arguments*/
int read_and_validate(int argc, char *argv[], Slist **head)
{
    if(argc < 2)
    {
        printf("Need to pass atleast 2 arguments...");
        return FAILURE;
    }

    for(int i = 1; i < argc; i++) 
    {
        char *ptr = strstr(argv[i], ".");  //checking file has . or not
        if(ptr == NULL)
        {
            printf("%s is an invalid file\n", argv[i]);
            continue;
        }

        if(strcmp(ptr, ".txt") != 0) //checking file has .txt extension or not
        {
            printf("%s does not contain .txt extension\n", argv[i]);
            continue;
        }

        /*Opening the file for checking file is empty or not*/
        FILE *fptr = fopen(argv[i], "r");
        if(fptr == NULL)
        {
            printf("Failed to open %s file\n", argv[i]);
            continue;
        }  

        /*Making the file pointer to point to end of the file*/
        fseek(fptr, 0, SEEK_END);

        /*Calculating the length of the file*/
        int len = ftell(fptr);
        fclose(fptr); 

        /*checking whether the file is empty or not*/ 
        if(len == 0)
        {
            printf("%s is empty file\n", argv[i]);
            continue;
        }

        /*Creating new node*/
        Slist *new = malloc(sizeof(Slist));
        if(new == NULL)
        {
            printf("Failed to create new node\n");
            continue;
        }

        /*Copying the file name*/
        strcpy(new->file, argv[i]);
        new->link = NULL;

        if(*head == NULL)
        {
            *head = new;
        }
        else
        {
            Slist *temp = *head;
            Slist *prev = NULL;
            int duplicate = 0;
            /*checking whether the file name already present in the list*/
            while(temp)
            {
                if(strcmp(temp->file, argv[i]) == 0)
                {
                    printf("%s is duplicate file\n", argv[i]);
                    duplicate = 1;
                }
                prev = temp;
                temp = temp->link;
            }
            if(duplicate)
            {
                continue;
            }
            prev->link = new;
        }

        printf("%s file added to the list\n", argv[i]);
    }

    return SUCCESS;
}
