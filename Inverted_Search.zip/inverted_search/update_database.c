#include "header.h"

/*Function to update data from a file to the database*/
int update_database(Main_node *arr[28], Slist **head)
{
    char backup_file[50];
    printf("Enter file name to update database: ");  //reading file name from the user
    scanf("%s", backup_file);
    
    /*Validating the file*/
    char *ptr = strstr(backup_file, ".");
    if(ptr == NULL || strcmp(ptr, ".txt") != 0)
    {
        printf("Give file name with .txt extension\n");
        return FAILURE;
    }

    //open file in read mode
    FILE *fptr = fopen(backup_file, "r");
    if(fptr == NULL)
    {
        printf("Failed to open the file: %s\n", backup_file);
        return FAILURE;
    }

    /*Checking whether it is a valid backup file or not*/
    char ch = fgetc(fptr);
    if(ch == '#')
    {
        fseek(fptr, -2, SEEK_END);
        if(fgetc(fptr) != '#')
        {
            printf("Give valid backup file to update\n");
            fclose(fptr);
            return FAILURE;
        }
        rewind(fptr);
    }

    else
    {
        printf("Give valid backup file to update\n");
        fclose(fptr);
        return FAILURE;
    }

    /*Redaing sentence from the file and updating it to database*/
    char sentence[100];
    while(fscanf(fptr, "%s", sentence) != EOF)
    {
        char *index = strtok(sentence, "#;");  //getting index from file
        if(index == NULL)
        {
            break;
        }

        int ind = atoi(index);                      //converting index from string to integer
        char *word = strtok(NULL, "#;");            // getting word from the user
        char *file_count = strtok(NULL, "#;");      //getting file count from the user
        int f_count = atoi(file_count);             //converting file count from string to integer

        if(word == NULL || file_count == NULL)
        {
            printf("Invalid format in file\n");
            fclose(fptr);
            return FAILURE;
        }

        if(arr[ind] == NULL)           //checking arr[index] is null or not
        {
            /*Creating msin node and updating data and linking it to the array*/
            Main_node *new_main = malloc(sizeof(Main_node));
            if(new_main == NULL)
            {
                printf("Failed to create new node for main node\n");
                fclose(fptr);
                return FAILURE;
            }

            new_main->file_count = f_count;
            strcpy(new_main->word, word);
            new_main->s_link = NULL;
            new_main->m_link = NULL;

            /*creating sub nodes based on the file count times and linking them to the main node*/
            for(int i = 0; i < f_count; i++)
            {
                char *file_name = strtok(NULL, "#;");  //getting file name from the file
                char *word_count = strtok(NULL, "#;");  //getting word count from the file
                int w_count = atoi(word_count);  //converting word count to integer

                if(file_name == NULL || word_count == NULL)
                {
                    printf("Invalid file name / word count in the file\n");
                    fclose(fptr);
                    return FAILURE;
                }

                //checking the files which are given in the command line arguments are same in the back up file or not
                Slist *temp_head = *head;
                Slist *prev = NULL;
                if(temp_head != NULL && strcmp(temp_head->file,file_name) == 0)
                {
                    *head = temp_head->link;
                    free(temp_head);                //deallocating them if duplicates found
                }

                while(temp_head != NULL && strcmp(temp_head->file, file_name) != 0)  //traversing till last node or same file name found
                {
                   
                    prev = temp_head;
                    temp_head = temp_head->link;
                }

                if(temp_head != NULL)
                {
                    prev->link = temp_head->link;
                    free(temp_head);                //deallocating them if duplicates found
                }

                /*creating sub node for file names and updating data and linking them to main node*/
                Sub_node *new_sub = malloc(sizeof(Sub_node));
                if(new_sub == NULL)
                {
                    printf("Failed to create new node for sub node\n");
                    fclose(fptr);
                    return FAILURE;
                }

                new_sub->word_count = w_count;
                strcpy(new_sub->file_name, file_name);
                new_sub->sub_link = new_main->s_link;
                new_main->s_link = new_sub;
            }
            arr[ind] = new_main;
        }

        else  //if in the arr[index] nodes already present , new main node and sub node is inserting at first of the list
        {

            Main_node *new_main = malloc(sizeof(Main_node));
            if(new_main == NULL)
            {
                printf("Failed to create new node for main node\n");
                fclose(fptr);
                return FAILURE;
            }

            new_main->file_count = f_count;
            strcpy(new_main->word, word);
            new_main->m_link = arr[ind];
            for(int i = 0; i < f_count; i++)
            {
                char *file_name = strtok(NULL, "#;");
                char *word_count = strtok(NULL, "#;");
                int w_count = atoi(word_count);

                if(file_name == NULL || word_count == NULL)
                {
                    printf("Invalid file name or word count in the file\n");
                    fclose(fptr);
                    return FAILURE;
                }

                Slist *temp_head = *head;
                Slist *prev = NULL;
                if(temp_head != NULL && strcmp(temp_head->file,file_name) == 0)
                {
                    *head = temp_head->link;
                    free(temp_head);
                }
                while(temp_head != NULL && strcmp(temp_head->file,file_name) != 0)
                {
                   
                    prev = temp_head;
                    temp_head = temp_head->link;
                }
                if(temp_head != NULL)
                {
                    prev->link = temp_head->link;
                    free(temp_head);
                }

                Sub_node *new_sub = malloc(sizeof(Sub_node));
                if (new_sub == NULL)
                {
                    printf("Failed to create new node for sub node\n");
                    fclose(fptr);
                    return FAILURE;
                }

                new_sub->word_count = w_count;
                strcpy(new_sub->file_name, file_name);
                new_sub->sub_link = new_main->s_link;
                new_main->s_link = new_sub;
            }
            arr[ind] = new_main;
        }
    }

    fclose(fptr);
    return SUCCESS;
}
