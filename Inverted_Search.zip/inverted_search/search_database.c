#include "header.h"

/*Function to search data in the database*/
int search_database(Main_node *arr[28])
{
    char word[50];
    printf("Enter word to search: ");  //reading word from the user
    scanf("%s", word);
    int index = find_index(word);  //finding index for given word
    Main_node *temp_main = arr[index];
    //traversing the index whether word is present or not
    while(temp_main)
    {
        if(strcmp(temp_main->word, word) == 0)
        {
            printf("%d\t", temp_main->file_count);
            
            Sub_node *temp_sub = temp_main->s_link;
            while (temp_sub)
            {
                printf("%s\t%d ", temp_sub->file_name, temp_sub->word_count);
                temp_sub = temp_sub->sub_link;
            }
            printf("\n");
            temp_main = temp_main->m_link;
            return SUCCESS;
        }
        temp_main = temp_main->m_link;
    }
    printf("%s word not found\n", word);
    return FAILURE;
}
